"""COMP6730 question 8.

This should be completed individually.

Author: <University ID>
Date: <Date>
"""


def plot_fire_spread(initial_bushfire, vegetation_type, vegetation_density, wind_speed):
    pass


if __name__ == '__main__':
    # If you want something to happen when you run this file,
    # put the code in this `if` block.
    pass
